<?php  require_once './controller/autenticar.php';

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Netflix</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        <link href="css/css.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="">
        <div id='bodypg1'>
        <div class="row">
    <div class="col-md-4"> </div>
    <div class="col-md-4"><br><br><br><br><br><br><br><br>
        <div class="login">

            <div class="row" style="padding: 20px">
                <div class="mb-3 mt-3">
                    <h1 style="color: #fff">ENTRAR</h1><br>
                    <input type="email" class="form-control" id="email" 
                    <form method="post" action="./controller/conttatest.php>
                           placeholder="Email ou numero de telefone" name="email" required="">
                <div class="mb-3 mt-3">
                   <input type="password" class="form-control" id="senha" 
                   placeholder="Senha" name="senha" required="">
                </div>
                </div>
                <<?php
                    if(isset($cod)){
                        if($cod=='171'){
                            echo ('<span style="color:darkorange;">Senha ou email invalido/span>');
                        }
                        if($cod=='172'){
                            echo ('<span style="color:darkorange;">Sua sessão expirou!</span>');
                        }
                    }
                    ?>
?>
                <div class="d-grid">
                   <button type="submit"class="btn btn-danger">Entrar</button>
                   
                   </form>
                </div></div></div></div></div></div>

        
    </body>
</html>
