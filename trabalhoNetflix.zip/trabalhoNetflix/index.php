<?php  require_once './controller/loginController.php'; ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Netflix</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        <link href="css/css.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="">
        <div class="row">
    <div class="col-md-4"> </div>
    <div class="col-md-4"><br><br><br><br><br><br><br><br>
        <div class="login">

            <div class="row" style=" margin: 30px 30px 30px 30px; padding: 20px">
                <div class="mb-3 mt-3">
                    <h1 style="color: #fff">ENTRAR</h1><br>
                    <input type="email" class="form-control" id="email" 
                           placeholder="Email ou numero de telefone" name="email" required="">
                <div class="mb-3 mt-3">
                   <input type="password" class="form-control" id="senha" 
                           placeholder="Senha" name="senha" required="">
                </div>
                </div>
                <div class="d-grid">
                    <input class="btn btn-danger" type="submit" value="Entrar"> </div></div></div>
        <?php
        // put your code here
        ?>
    </body>
</html>
