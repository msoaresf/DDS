<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Netflix</title>
        <link href="frameworks/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="frameworks/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="frameworks/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="frameworks/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="frameworks/jquery.dataTables.min.js" type="text/javascript"></script>
    </head></html>