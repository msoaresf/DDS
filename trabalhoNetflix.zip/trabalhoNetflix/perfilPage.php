<?php  require_once './controller/loginController.php';
require_once './controller/autenticar.php';?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Netflix</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        <link href="css/css.css" rel="stylesheet" type="text/css"/>
    </head>
    <body><div id='bodypg'>
              <div class="row">
        <div class="col-3"></div>
        <div class="col-6">
            <center><h2 class="mb-5 mt-5">Quem está assistindo?</h2></center><br>
            
            <div class="row">
                      <?php
                   {
                  
                        $result = array(
                       array('nome'=>'Duda','img'=>'./img/1perfil.png'),
                        array('nome'=>'Infantil','img'=>'./img/2perfil.jpg'),
                         );  
                    }
                    
                    foreach ($result as $data){
                        echo('<div class="col-4"><a href="./filmes.php?account='.$data["nome"].'"><img class="grow" src="'.$data["img"].'" alt=""/></a><br><center><h3 class="mb-3 mt-3">'.$data["nome"].'</h3></center></div>');
                    }
                    ?>
            </div>
            
            <center><a href="./controller/logout.php?cod=logout" class="mb-5 mt-5 nav-link"><h4 id="lg">Sair</h4></a></center>
        </div>
        <div class="col-3"></div>
    </div>
       
        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>