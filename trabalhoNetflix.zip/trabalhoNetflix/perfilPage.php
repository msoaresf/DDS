<?php  require_once './controller/loginController.php'; ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Netflix</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        <link href="css/css.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
       
        <?php
        // put your code here
        ?>
    </body>
</html>