<?php

if($_POST){
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    
    $dados = array('email'=>'a@a','senha'=>'asasas');
    
    if ($email == $dados['email'] && $senha == $dados['senha']){
        session_start();
        
        $_SESSION['login'] = $email;
        
        header('location:../accounts.php');
    }else{
        header('location:../index.php?cod=171');
    }
}else{
    header('location:../index.php');
}