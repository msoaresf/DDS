<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link href="css/default.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <title>Honda</title>
    </head>
    <body>
 <form method="post" action="index.php">
        <div class="container">
            
            <div class="row">
                <div class="col-sm-1"></div>
                    <div class="col-sm-10">
                    
                        
                        
                        <h1 class="corr">Formulario de seleção de Acessórios - Montadora HONDA veículos</h1><br><br>
                    
                        <div class="form-group">
                        <label for="cor">Cor do Veículo:</label>
                        <input type="text" name="cor" class="form-control" id="cor" placeholder="Digite a cor do veículo"></div><br>
                        
                      <div class="form-group">    
                        <label for="modelo">Modelo do Veículo:</label><br>
                        <select class="form-control" name="modelo">
                            <option value=""> Selecione o modelo do veículo</option>
                            <option value="Civic">Civic</option>
                            <option value="Accord">Accord</option>
                            <option value="CR-V">CR-V</option>
                            <option value="Fit">Fit</option>
                            <option value="City">City</option>
                            <option value="WR-V">WR-V</option>
                            <option value="Jazz">Jazz</option>
                            <option value="Pilot">Pilot</option>
                            <option value="Odyssey">Odyssey</option>
                            
                        </select></div><br>
                         <div class="form-group">
                         <label for="acessorio">Acessórios:</label>
                         <div class="checkbox">
                             <div class="corr">
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Rodas de liga leve">Rodas de liga leve<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Teto Solar">Teto solar<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Bancos em couro">Bancos em couro<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Ar-Condicionado digital">Ar-Condicionado digital<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Central multimídia">Central Multimídia<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Sensor de Estacionamento">Sensor de Estacionamento<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Câmera de ré">Câmera de ré<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Faróis de LED">Faróis de LED<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Bancos com aquecimento">Bancos com aquecimento<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Sistema de navegação GPS">Sistema de navegação GPS<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Sensor de chuva">Sensor de chuva<br>
                             <input type="checkbox" name="acessorio[]" id="acessorio" value="Controle de cruzeiro">Controle de cruzeiro<br><br></div></div>
                      
                    
                    <label for="cor">Observações:</label>
                    <input type="textarea" name="obs" class="form-control" id="obs" placeholder="Digite quais quer observações"> <br><br>
                        
                    <input type="submit" value="Confirmar seleçao dos acessorios" class="btn btn-danger"></input>    
                    
                  
         <?php
          
         if($_POST){
             
            // print_r($_POST);
             @$cor=$_POST['cor'];
             @$modelo=$_POST['modelo'];
             @$acessorio=$_POST['acessorio'];
             @$obs=$_POST['obs'];
             
            
             
             if(empty($cor)||empty($modelo)||empty($acessorio)||empty($obs)){
                
                 echo ('<br> <br> <div class="panel panel-dager">
                     <div class="panel-heading">TODOS OS DADOS DEVEM SER INFORMADOS</div></div>');
             }else{
             echo ('<br><br><div class="panel panel-success">
                     <div class="panel-heading">DADOS INFORMADOS</div>
                     <div class="panel panel-body"> 
                     <p>Cor do Veículo:'.$cor.'<p> 
                     <p>Modelo do Veículo:'.$modelo.'<p> 
                     <p>Acessorios:'.implode(" & ",$acessorio).'<p> 
                     <p>Observações:'.$obs.'<p> </div></div>');
             
             }
         }
         
        ?>
                    </div></div></div></form>
    </body>
</html>
