<?php 
require_once './shared/header.php';
?>
<style>
.login{
    border-radius: 4%;
    background-color: rgba(171, 204, 149, 0.452);
    padding: 10%;
}

</style>

<div class="container">
<div class="row"><br><br><br><br><br><br><br><br>
    <div class="col-sm-4"></div>
     <div class="col-sm-4">
      <div class="login">
      <h1>Login</h1>
                
                  
               
                <div class="form-group">
                    <label for="nome">Email:</label>
                    <input type="texr" class="form-control" id="email" placeholder="Email" name="email" required="">
                </div>
                <div class="form-group">
                    <label for="descricao">Senha:</label>
                    <input type="password" class="form-control" id="senha"  placeholder="Senha" name="senha" required=""> 
                </div> 
                <p>Não possui conta? <a href="cadastroUsuario.php">Cadastrar-se</a></P>
                <div class="d-grid">
                   <button type="submit"class="btn btn-info">Entrar</button>
                 </div>

  </div>
 </div>
</div>

</div>

