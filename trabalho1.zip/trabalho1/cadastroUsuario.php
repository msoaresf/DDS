<?php 
require_once './shared/header.php';
?>
<style>
.login{
    border-radius: 4%;
    background-color: rgba(171, 204, 149, 0.452);
    padding: 10%;
}

</style>

<div class="container">
<div class="row"><br><br><br><br><br><br><br><br>
    <div class="col-sm-4"></div>
     <div class="col-sm-4">
      <div class="login">
      <h1>Cadastro Usuario</h1>
                
                  
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control" id="nome" placeholder="Nome" name="nome" required="">
                </div>
                <div class="form-group">
                    <label for="nome">Email:</label>
                    <input type="texr" class="form-control" id="email" placeholder="Email" name="email" required="">
                </div>
                <div class="form-group">
                    <label for="descricao">Senha:</label>
                    <input type="password" class="form-control" id="senha"  placeholder="Senha" name="senha" required=""> 
                </div> 
                <p>Possui conta? <a href="login.php">Login</a></P>
                <div class="d-grid">
                   <button type="submit"class="btn btn-info">Entrar</button>
                 </div>

  </div>
 </div>
</div>

</div>

