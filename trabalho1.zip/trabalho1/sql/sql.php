create database banco
use banco

create table tipoUsuario(
id int auto_increment not null,
nome varchar(40),
primary key (id)
);

create table usuario(
id int auto_increment not null,
nome varchar(40),
email varchar(40),
senha varchar(40),
tipoUsuarioId int, 
foreign key (tipoUsuarioId) references tipoUsuario(id),
primary key (id));

create table itens(
id int auto_increment not null,
nome varchar(40),
descricao varchar(60),
quantidade int,
precoCusto float,
precoVenda float,
dataCadastro date,
usuarioId int,
foreign key(usuarioId) references usuario(id),
primary key (id)
);
create table pedidos(
id int auto_increment not null,
dataCompra date,
dataAprovacao date,
valorTotal Float,
usuarioId int,
foreign key(usuarioId) references usuario(id),
primary key (id)
);
create table pedidoItens(
id int auto_increment not null,
itemId int,
quantidade int,
foreign key (itemId) references itens(id),
primary key (id));