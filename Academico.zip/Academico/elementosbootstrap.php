<html>
    <head>
        <meta charset="UTF-8">
        <title>Table</title>
   
    </head>

    <body>
        
        <table> <thead>
                <tr>
                    <td>Nome</td>
                    <td>Sobrenome</td>
                    
                </tr> 
                
                
             </thead>
        
    </body></html>