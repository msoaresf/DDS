<html>
    <head>
        <meta charset="UTF-8">
        <title>Table</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
   
    </head>

    <body>
        
        <table class="table-condensed"> <thead>
                <tr>
                    <td>Nome</td>
                    <td>Sobrenome</td>
                    
                </tr> 
                <tr>
                    <td> Duda</td>
                    <td> Soares </td>
                       
                    <td> <a href="img/images.jfif"></a></td>   
                       
                    
                </tr>
                
                
             </thead>
             <a href="img/images.jfif"></a>
    </body></html>